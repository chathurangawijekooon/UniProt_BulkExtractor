# UniProt Bulk Extractor

A free, open-source browser tool to extract UniProt IDs from SwissTargetPrediction Excel files — no installation, no server, works fully offline.

![MIT License](https://img.shields.io/badge/license-MIT-green)
![No Install](https://img.shields.io/badge/install-none-blue)
![Works Offline](https://img.shields.io/badge/offline-yes-brightgreen)

---

## What it does

- Upload up to **100 Excel files** at once
- Automatically detects the `Uniprot ID` and `Common name` columns
- Extracts only rows where **Probability > 0**
- Preview results in the browser
- Download everything as a single clean **Excel file**

---

## How to use

1. Download `UniProt_BulkExtractor.html`
2. Open it in **Chrome** or **Edge**
3. Drop your SwissTargetPrediction `.xlsx` files
4. Click **Extract from All Files**
5. Click **Download Excel**

No installation. No internet required. Everything runs in your browser.

---

## Input format

Designed for **SwissTargetPrediction** export files (`.xlsx`), which look like this:

| Row | Content |
|-----|---------|
| 1 | Title row (SwissTargetPrediction) |
| 2 | Headers: Target, Common name, Uniprot ID, Probability\*, ... |
| 3+ | Data |

The tool automatically skips the title row and finds the correct header row.

---

## Output columns

| Column | Description |
|--------|-------------|
| Uniprot ID | UniProt accession number |
| Common Name | Gene/protein common name |
| Probability | Prediction probability (> 0 only) |
| Source File | Name of the original Excel file |

---

## License

MIT License — free to use, modify, and share.

This tool embeds the [SheetJS](https://sheetjs.com) library (Apache 2.0) for Excel reading and writing.

---

## Contributing

Pull requests welcome! If your SwissTargetPrediction file has a different format and the tool doesn't work, please open an issue and attach a sample file.
